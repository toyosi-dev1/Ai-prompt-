# AI Prompt Studio

A creative prompt-building workspace for designers, content creators, marketers, and AI visual creators. Describe a rough idea, shape it with structured controls, and get a polished, production-ready AI prompt.

AI Prompt Studio runs entirely in the browser. It does not call an AI model or any external API: prompts are produced by a deterministic, seeded generator that composes the idea with the chosen style, lighting, composition, and format.

## Features

- Studio workspace with prompt type (Image, Video, Text), visual style, aspect ratio, lighting, and camera or composition controls
- Simulated generation with a loading state, animated reveal, copy, save, and regenerate
- Structured breakdown of every prompt: subject, environment, composition, lighting, style, technical direction, and format
- My Prompts library with search, style filter, expandable previews, copy, and delete
- Eight starter templates that fill the Studio form without generating automatically
- Global search across saved prompts and templates (`Ctrl+K` / `Cmd+K`)
- Dark and light themes, plus default prompt type, style, and aspect ratio preferences
- Toast notifications, confirmation dialogs, and graceful fallbacks when `localStorage` or the clipboard is unavailable
- Responsive layout with a keyboard-accessible mobile drawer, visible focus states, and reduced-motion support

## Tech Stack

React 18, Vite, Tailwind CSS, JavaScript, Lucide icons, and `localStorage`. There is no router library, state library, or animation library.

## Screenshots

Add screenshots to `docs/screenshots` and reference them here.

| Studio | My Prompts | Templates |
| --- | --- | --- |
| _coming soon_ | _coming soon_ | _coming soon_ |

## Live Demo

`https://USERNAME.github.io/REPOSITORY-NAME/`

## Getting Started

Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Create and preview a production build:

```bash
npm run build
npm run preview
```

## Deployment

The app uses hash-based routing and a relative Vite base (`base: './'`), so it works from `https://USERNAME.github.io/REPOSITORY-NAME/` without extra configuration or redirect files.

1. Create a GitHub repository and push this project to the `main` branch.
2. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main`. The workflow in `.github/workflows/deploy.yml` installs dependencies, builds the app, and publishes `dist`.
4. Update `PROJECT_URL` in `src/data/constants.js` with your repository URL, and replace the live demo link above.

## Project Structure

```
src/
  components/   Sidebar, Header, PromptForm, PromptOutput, PromptMetadata, PromptCard,
                TemplateCard, SelectControl, SegmentedControl, Modal, SearchModal, AppShell
  context/      App state, Studio form state, toasts
  data/         Templates and option lists
  pages/        Studio, MyPrompts, Templates, Settings
  utils/        promptGenerator, profiles, storage, router, search, clipboard hook
```

## How Prompt Generation Works

`generatePrompt()` in `src/utils/promptGenerator.js` takes the idea, prompt type, style, aspect ratio, lighting, and composition. It looks up a profile for each choice in `src/utils/profiles.js`, detects product cues in the idea (fragrance, hardware, beverages, food, accessories) to add relevant detail, and assembles sentences from phrase variants. A seeded random generator, derived from the inputs plus a variant number, picks the phrasing, so the same inputs always return the same prompt and Regenerate increments the variant for a different one.

## Project Purpose

AI Prompt Studio is a frontend, AI-inspired creative prompt workspace. It demonstrates React development, interaction design, accessibility, and AI product thinking. No real AI model or API is used.
